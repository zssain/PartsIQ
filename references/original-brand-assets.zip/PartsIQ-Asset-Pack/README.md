# PartsIQ Asset Pack

Based on the exact first-concept logo uploaded by you.

## Contents
- web/: multi-resolution ICO (16–256px), PNG favicons, Apple touch icon, PWA icons, maskable icons, web manifest, HTML integration snippet.
- logos/: full bilingual logo in white-background and transparent PNG at 320, 640, 1280 and 1740px widths.
- icons/: symbol-only white-background and transparent PNG, 16–1024px.
- mobile/: iOS App Store, Google Play, and Android legacy launcher density exports.
- social/: 1200x630 link-preview image and 1080px square profile image.
- source/: original upload and AI-extracted transparent derivative.

## Website setup
Copy the contents of web/ into your site's public/ directory. Add head-snippet.html's tags to your page head. Adjust start_url and root-relative paths if hosted below a subpath. The manifest supplies branding only; it does not implement offline functionality.

## Fidelity and usage
White-background exports are cropped/resized directly from your original upload. Transparent exports use an AI background-extracted derivative, so minor edge/color differences can exist. For exact fidelity use the white-background files. Use the symbol alone for favicon/app icon sizes; bilingual lettering is retained in full logos. The original detail is naturally less legible at 16px.

Maskable icons use a smaller centered mark with generous safe padding. Mobile files are store and legacy launcher exports, not a full platform asset catalog or Android adaptive foreground/background package.

PNG/ICO assets are raster, not editable vector artwork. No false SVG wrapper is included. Source logo is 1999x786; larger icon exports are resampled and do not add source detail. Use a vector redraw for large-format printing. Palette guide: navy #2B2D7F, warm gold approximately #C59A45, grey wings; source includes subtle tonal variations.

To reproduce exports, keep source/ files in place and update build_assets.py source paths if necessary.
