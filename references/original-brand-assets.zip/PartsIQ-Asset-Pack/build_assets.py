from pathlib import Path
from PIL import Image, ImageOps, ImageDraw
import json, shutil, zipfile

ROOT=Path(__file__).parent
R=Image.Resampling.LANCZOS
for d in ['source','logos','icons','web','mobile','social']:
    (ROOT/d).mkdir(exist_ok=True)
original=Image.open(ROOT/'source/original-logo.png').convert('RGBA')
transparent=Image.open(ROOT/'source/transparent-logo.png').convert('RGBA')
original.save(ROOT/'source/original-logo.png')
transparent.save(ROOT/'source/transparent-logo.png')

def fit(im, size, bg=(255,255,255,0), fraction=.90):
    out=Image.new('RGBA',size,bg)
    thumb=ImageOps.contain(im,(round(size[0]*fraction),round(size[1]*fraction)),R)
    out.alpha_composite(thumb,((size[0]-thumb.width)//2,(size[1]-thumb.height)//2))
    return out

logo=original.crop((130,60,1870,720))
logo_alpha=transparent.crop((130,60,1870,720))
icon=original.crop((135,65,763,714))
icon_alpha=transparent.crop((135,60,763,720))
for width in [320,640,1280,1740]:
    h=round(width*logo.height/logo.width)
    logo.resize((width,h),R).save(ROOT/f'logos/partsiq-logo-white-{width}.png')
    logo_alpha.resize((width,h),R).save(ROOT/f'logos/partsiq-logo-transparent-{width}.png')

for s in [16,24,32,48,64,96,128,144,152,180,192,256,384,512,1024]:
    # Opaque exports use the original uploaded artwork without regeneration.
    fit(icon,(s,s),(255,255,255,255),.90).convert('RGB').save(ROOT/f'icons/partsiq-icon-white-{s}.png')
    fit(icon_alpha,(s,s),fraction=.90).save(ROOT/f'icons/partsiq-icon-transparent-{s}.png')
for s in [16,32,48,96]:
    shutil.copy(ROOT/f'icons/partsiq-icon-white-{s}.png', ROOT/f'web/favicon-{s}x{s}.png')
fit(icon,(256,256),(255,255,255,255),.90).save(ROOT/'web/favicon.ico',sizes=[(s,s) for s in [16,24,32,48,64,128,256]])
for s in [180]:
    shutil.copy(ROOT/f'icons/partsiq-icon-white-{s}.png',ROOT/'web/apple-touch-icon.png')
for s in [192,512]:
    shutil.copy(ROOT/f'icons/partsiq-icon-white-{s}.png',ROOT/f'web/android-chrome-{s}x{s}.png')
    fit(icon,(s,s),(255,255,255,255),.66).convert('RGB').save(ROOT/f'web/maskable-icon-{s}x{s}.png')
shutil.copy(ROOT/'icons/partsiq-icon-white-1024.png',ROOT/'mobile/ios-app-store-1024.png')
shutil.copy(ROOT/'icons/partsiq-icon-white-512.png',ROOT/'mobile/google-play-512.png')
for density,s in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
    fit(icon,(s,s),(255,255,255,255),.9).convert('RGB').save(ROOT/f'mobile/android-launcher-{density}-{s}.png')
fit(logo,(1200,630),(255,255,255,255),.86).convert('RGB').save(ROOT/'social/partsiq-og-1200x630.png')
fit(icon,(1080,1080),(255,255,255,255),.8).convert('RGB').save(ROOT/'social/partsiq-profile-1080.png')
manifest={'name':'PartsIQ','short_name':'PartsIQ','start_url':'/','display':'standalone','background_color':'#FFFFFF','theme_color':'#2B2D7F','icons':[]}
for s in [192,512]:
    manifest['icons'] += [{'src':f'/android-chrome-{s}x{s}.png','sizes':f'{s}x{s}','type':'image/png','purpose':'any'},{'src':f'/maskable-icon-{s}x{s}.png','sizes':f'{s}x{s}','type':'image/png','purpose':'maskable'}]
(ROOT/'web/site.webmanifest').write_text(json.dumps(manifest,indent=2))
(ROOT/'web/head-snippet.html').write_text('''<!-- Copy web/ assets into your public/ directory, then add these to <head>. -->
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<meta name="theme-color" content="#2B2D7F">
''')
(ROOT/'README.md').write_text('''# PartsIQ Asset Pack

Based on the exact first-concept logo uploaded by you.

## Contents
- web/: multi-resolution ICO (16–256px), PNG favicons, Apple touch icon, PWA icons, maskable icons, web manifest, HTML integration snippet.
- logos/: full bilingual logo in white-background and transparent PNG at 320, 640, 1280 and 1740px widths.
- icons/: symbol-only white-background and transparent PNG, 16–1024px.
- mobile/: iOS App Store, Google Play, and Android legacy launcher density exports.
- social/: 1200x630 link-preview image and 1080px square profile image.
- source/: original upload and AI-extracted transparent derivative.

## Website setup
Copy the contents of web/ into your site's public/ directory. Add head-snippet.html's tags to your page head. Adjust start_url and root-relative paths if hosted below a subpath. The manifest supplies branding only; it does not implement offline functionality.

## Fidelity and usage
White-background exports are cropped/resized directly from your original upload. Transparent exports use an AI background-extracted derivative, so minor edge/color differences can exist. For exact fidelity use the white-background files. Use the symbol alone for favicon/app icon sizes; bilingual lettering is retained in full logos. The original detail is naturally less legible at 16px.

Maskable icons use a smaller centered mark with generous safe padding. Mobile files are store and legacy launcher exports, not a full platform asset catalog or Android adaptive foreground/background package.

PNG/ICO assets are raster, not editable vector artwork. No false SVG wrapper is included. Source logo is 1999x786; larger icon exports are resampled and do not add source detail. Use a vector redraw for large-format printing. Palette guide: navy #2B2D7F, warm gold approximately #C59A45, grey wings; source includes subtle tonal variations.

To reproduce exports, keep source/ files in place and update build_assets.py source paths if necessary.
''')
# Self-contained reproduction paths.
script=Path(__file__).read_text().replace("ROOT/'source/original-logo.png'","ROOT/'source/original-logo.png'").replace("ROOT/'source/transparent-logo.png'","ROOT/'source/transparent-logo.png'")
Path(__file__).write_text(script)
preview=Image.new('RGB',(1200,760),'#F2F4F8');d=ImageDraw.Draw(preview)
d.text((40,25),'PartsIQ | Asset preview',fill='#2B2D7F')
preview.paste(fit(logo,(1120,370),(255,255,255,255),.9).convert('RGB'),(40,65))
for i,s in enumerate([16,32,48,96,180]):
    x=65+i*220
    im=fit(icon,(s,s),(255,255,255,255),.9).convert('RGB')
    preview.paste(im,(x,490));d.text((x,690),f'{s} px',fill='#2B2D7F')
preview.save(ROOT/'Preview.png')
for p in ROOT.rglob('*.png'):
    with Image.open(p) as im: im.verify()
ico=Image.open(ROOT/'web/favicon.ico')
assert (16,16) in ico.ico.sizes() and (256,256) in ico.ico.sizes()
for item in manifest['icons']: assert (ROOT/'web'/item['src'][1:]).exists()
with zipfile.ZipFile(ROOT.parent/'PartsIQ-Asset-Pack.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file(): z.write(p,Path(ROOT.name)/p.relative_to(ROOT))
print('Verified',len(list(ROOT.rglob('*.png'))),'PNG files; ICO frames:',sorted(ico.ico.sizes()))
